# Supported Countries & TLDs

Use either `country` or `tld` parameter in your API requests. Both refer to the same Amazon marketplace.

| `country` code | `tld` value | Amazon Domain |
|---|---|---|
| `us` | `com` | amazon.com |
| `uk` | `co.uk` | amazon.co.uk |
| `ca` | `ca` | amazon.ca |
| `de` | `de` | amazon.de |
| `fr` | `fr` | amazon.fr |
| `it` | `it` | amazon.it |
| `es` | `es` | amazon.es |
| `nl` | `nl` | amazon.nl |
| `pl` | `pl` | amazon.pl |
| `ro` | `ro` | amazon.ro |
| `tr` | `com.tr` | amazon.com.tr |
| `in` | `in` | amazon.in |
| `mx` | `com.mx` | amazon.com.mx |
| `br` | `com.br` | amazon.com.br |
| `sa` | `sa` | amazon.sa |
| `ae` | `ae` | amazon.ae |
| `jp` | `co.jp` | amazon.co.jp |
| `au` | `com.au` | amazon.com.au |

## Usage examples

```
# Search in Germany
?api_key=KEY&query=kopfhörer&country=de

# Product detail from Japan
?api_key=KEY&asin=B0ABC123&country=jp

# Using tld instead of country
?api_key=KEY&query=laptops&tld=co.uk
```

## Important note
If a product is not listed in the specified marketplace, the API may silently fall back to `amazon.com`. Always check the `url` field in the response to confirm which marketplace was actually queried.