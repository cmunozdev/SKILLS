---
name: scrapeops-amazon-api
description: Use this skill whenever the user wants to fetch, search, analyze, or work with Amazon product data using the ScrapeOps API. Triggers include: searching for products on Amazon, getting product details by ASIN or URL, monitoring prices, comparing products, scraping product specs or reviews, building price trackers, analyzing Amazon listings, fetching product availability or ratings, or any task that involves retrieving structured Amazon data programmatically. Use this skill even if the user just mentions "Amazon product data", "check price on Amazon", "get Amazon reviews", or "look up an ASIN" — it almost certainly applies.
---

# ScrapeOps Amazon API Skill

This skill enables Claude to fetch structured Amazon product data using the ScrapeOps Data API — both for individual product pages and search result pages.

## Authentication

Every request requires an `api_key` query parameter. Without it, the API returns `403 Forbidden`.

```
api_key=YOUR_API_KEY
```

The user must provide their API key. Free keys are available at https://scrapeops.io/app/register/proxy/

---

## Two Endpoints Available

### 1. Product Search API — `amazon/search`
Fetches a list of products from an Amazon search results page.

**Base URL:**
```
https://proxy.scrapeops.io/v1/structured-data/amazon/search
```

**Query methods (use one):**

By search term:
```
?api_key=KEY&query=iphone&country=us
```

By full search URL (URL-encoded, takes priority over `query`):
```
?api_key=KEY&url=https%3A%2F%2Fwww.amazon.com%2Fs%3Fk%3Diphone
```

**Parameters:**
| Parameter | Required | Description |
|---|---|---|
| `api_key` | ✅ | Authentication key |
| `query` | One of these | Search term (e.g. `"wireless headphones"`) |
| `url` | One of these | Full encoded URL of Amazon search page |
| `country` | No | 2-letter country code: `us`, `uk`, `de`, `fr`, etc. |
| `tld` | No | Amazon domain: `com`, `co.uk`, `de`, etc. |

→ For full country/TLD table, see `references/countries.md`

---

### 2. Product Detail API — `amazon/product`
Fetches complete data for a single Amazon product page.

**Base URL:**
```
https://proxy.scrapeops.io/v1/structured-data/amazon/product
```

**Query methods (use one):**

By ASIN:
```
?api_key=KEY&asin=B0BNLTS1T3&country=us
```

By product URL (URL-encoded, takes priority over `asin`):
```
?api_key=KEY&url=https%3A%2F%2Fwww.amazon.com%2Fdp%2FB0BNLTS1T3
```

**Parameters:**
| Parameter | Required | Description |
|---|---|---|
| `api_key` | ✅ | Authentication key |
| `asin` | One of these | Amazon Standard Identification Number |
| `url` | One of these | Full encoded URL of product page |
| `country` | No | 2-letter country code |
| `tld` | No | Amazon domain TLD |

---

## Response Schemas

### Search API Response

```json
{
  "status": "parse_successful",
  "url": "https://www.amazon.com/s?k=query",
  "data": {
    "total_results": 5000,
    "results": [ ...array of product objects... ]
  }
}
```

**Each product object in `results`:**
| Field | Type | Always present | Description |
|---|---|---|---|
| `asin` | string | ✅ | Unique Amazon product ID |
| `name` | string | ✅ | Full product title |
| `price` | number | ✅ | Current price (USD or local currency) |
| `original_price` | number | ❌ | Pre-discount price (only if discounted) |
| `stars` | number | ✅ | Rating (e.g. `4.7`) |
| `image` | string | ✅ | Product thumbnail URL |
| `url` | string | ✅ | Full Amazon product URL |
| `badge` | string | ❌ | Promo label: `"Overall Pick"`, `"Limited time deal"`, `"Ends in"` |
| `shipping` | string | ❌ | Shipping info (e.g. `"20% off coupon applied"`) |

> **Note:** `original_price` can sometimes contain incorrect values due to Amazon's data inconsistencies. Validate before trusting.

> **Note on pagination:** The API returns ~48 results per call. To get more pages, pass the encoded URL of page 2, 3, etc. using the `url` parameter.

---

### Product Detail API Response

```json
{
  "status": "parse_successful",
  "url": "https://www.amazon.com/dp/ASIN",
  "data": { ...full product object... }
}
```

**Product detail fields:**

#### Core Identity
| Field | Type | Notes |
|---|---|---|
| `name` | string | Full product title |
| `brand` | string | Brand as shown on Amazon (may include "Visit the X Store") |
| `brand_url` | string | URL to brand's Amazon storefront |
| `model` | string\|null | Model number if available |
| `product_category` | string | Breadcrumb path (e.g. `"Home & Kitchen›Cookware›Stockpots"`) |

#### Pricing
| Field | Type | Notes |
|---|---|---|
| `pricing` | string | Current price with symbol (e.g. `"$29.99"`) |
| `list_price` | string | Original/list price with symbol |
| `is_coupon_exists` | boolean | Whether a coupon is available |

#### Inventory & Shipping
| Field | Type | Notes |
|---|---|---|
| `availability_status` | string | e.g. `"In Stock"`, `"Out of Stock"` |
| `shipping_price` | string | e.g. `"FREE"` or amount |
| `shipping_time` | string | Estimated delivery date |
| `shipping_condition` | string | Condition for free shipping |
| `ships_from` | string | Fulfillment source (may be empty) |
| `sold_by` | string | Seller name (may be empty) |

#### Content & Media
| Field | Type | Notes |
|---|---|---|
| `images` | string[] | Array of image URLs (main + thumbnails + video thumbnail) |
| `feature_bullets` | string[] | Key product bullet points |
| `full_description` | string | Long product description (may be empty for basic listings) |
| `aplus_present` | boolean | Whether seller has A+ enhanced content |

#### Product Variants
```json
"customization_options": {
  "Color": [
    { "asin": "B0ABC123", "value": "Black", "image": "...", "is_selected": true },
    { "asin": "B0ABC124", "value": "Blue",  "image": "...", "is_selected": false }
  ]
}
```
This is highly valuable — it reveals all variant ASINs automatically. Iterate over these to fetch full data for each variant.

#### Ratings & Reviews
| Field | Type | Notes |
|---|---|---|
| `average_rating` | number | e.g. `4.7` |
| `total_ratings` | number | Total number of ratings |
| `total_reviews` | number | Total number of written reviews |
| `1_star_percentage` | number | % of 1-star ratings (0 if not scraped) |
| `2_star_percentage` | number | % of 2-star ratings |
| `3_star_percentage` | number | % of 3-star ratings |
| `4_star_percentage` | number | % of 4-star ratings |
| `5_star_percentage` | number | % of 5-star ratings |

> **Known limitation:** Star percentage fields may all return `0` on some listings where Amazon loads them dynamically. This is not consistent — products with richer data return correct values.

#### Review Objects (in `reviews` array)
| Field | Type | Notes |
|---|---|---|
| `title` | string | Review headline |
| `review` | string | Full review text |
| `stars` | number | Individual star rating |
| `date` | string | Date as text (e.g. `"February 15, 2026"`) |
| `username` | string | Reviewer display name |
| `userUrl` | string | URL to reviewer profile |
| `reviewUrl` | string | Direct URL to review |
| `verified_purchase` | boolean | Whether it's a verified purchase |
| `total_found_helpful` | number | How many users found it helpful |
| `manufacturer_replied` | boolean | Whether seller replied |
| `images` | string[]\|null | Photos attached to review |
| `variation` | object | Which variant was purchased (e.g. `{"Color": "Blue"}`) |

> `reviews` may return `null` on some listings. This is a known scraping limitation for products where Amazon lazy-loads reviews.

#### Technical Specifications (`product_information`)
A flat key-value object with any/all of:
- `ASIN`, `Brand`, `Model`, `Color`, `Size`, `Capacity`
- `Material`, `Coating Description`, `Finish Type`
- `Product Dimensions`, `Item Weight`
- `Is Oven Safe`, `Is Suitable For Stovetop`
- `Best Sellers Rank` ← very useful for competitive analysis
- `Date First Available`
- `UPC`, `Manufacturer`, `Number of Packs`

> This object is empty `{}` on simple listings that have no tech spec table. It's most reliable on physical goods with detailed specs.

---

## Common Patterns & Workflows

### Pattern 1: Search → Detail (most powerful combo)
```
1. Call Search API with a query
2. Extract ASINs from results
3. Call Product API for each ASIN to get full details
```
This is the recommended approach for building product catalogs, comparison tools, or price monitors.

### Pattern 2: Price monitoring
```
1. Store a list of ASINs
2. Call Product API for each ASIN on a schedule
3. Compare `pricing` against stored previous value
4. Alert when price drops
```

### Pattern 3: Variant discovery
```
1. Call Product API for any known ASIN
2. Extract all ASINs from customization_options
3. Call Product API for each variant ASIN
4. Build complete variant pricing/availability matrix
```

### Pattern 4: Competitive analysis
```
1. Search for a category or keyword
2. Collect all ASINs, prices, ratings, badges
3. Sort/filter by stars, price, or badge presence
4. Identify market leaders by Best Sellers Rank in product_information
```

---

## Important Limitations & Gotchas

- **`country` parameter inconsistency:** If a product doesn't exist in the specified country's Amazon store, the API may silently fall back to `amazon.com`. Always verify the response URL.
- **No pagination token:** To paginate, pass the next page's full URL via the `url` parameter.
- **No filtering in Search API:** No built-in parameters for price range, category, minimum stars, etc. Filter the results yourself after fetching.
- **Dynamic content:** Some fields (`reviews`, `star_percentages`, `sold_by`, `ships_from`) are loaded by Amazon via JavaScript. The API may not capture these consistently.
- **`original_price` reliability:** This field sometimes contains incorrect values from Amazon's data — treat with caution and validate against the actual page if critical.
- **Rate limits & pricing:** Not documented in the public API docs. Check https://scrapeops.io for current plan details.

---

## Code Examples

### Python — Search products
```python
import requests

def search_amazon(query, api_key, country="us"):
    url = "https://proxy.scrapeops.io/v1/structured-data/amazon/search"
    params = {"api_key": api_key, "query": query, "country": country}
    response = requests.get(url, params=params)
    data = response.json()
    if data["status"] == "parse_successful":
        return data["data"]["results"]
    return []

results = search_amazon("wireless headphones", api_key="YOUR_KEY")
for product in results:
    print(f"{product['name']} — ${product['price']} ⭐{product['stars']}")
```

### Python — Get product detail
```python
def get_product(asin, api_key, country="us"):
    url = "https://proxy.scrapeops.io/v1/structured-data/amazon/product"
    params = {"api_key": api_key, "asin": asin, "country": country}
    response = requests.get(url, params=params)
    data = response.json()
    if data["status"] == "parse_successful":
        return data["data"]
    return None

product = get_product("B0FWTVLNYX", api_key="YOUR_KEY")
print(product["name"], product["pricing"], product["availability_status"])
```

### Python — Discover all variants
```python
def get_all_variants(asin, api_key):
    product = get_product(asin, api_key)
    variants = []
    options = product.get("customization_options", {})
    for option_type, option_list in options.items():
        for variant in option_list:
            variant_data = get_product(variant["asin"], api_key)
            variants.append({
                "asin": variant["asin"],
                "value": variant["value"],
                "price": variant_data.get("pricing"),
                "available": variant_data.get("availability_status")
            })
    return variants
```

---

## Quick Reference

| Task | Endpoint | Key param |
|---|---|---|
| Search by keyword | `amazon/search` | `query=...` |
| Search by page URL | `amazon/search` | `url=...` |
| Product by ASIN | `amazon/product` | `asin=...` |
| Product by URL | `amazon/product` | `url=...` |
| Specific country | Either | `country=us/uk/de/...` |

For the full list of supported countries and TLDs → see `references/countries.md`